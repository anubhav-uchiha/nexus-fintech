import { Module } from '@nestjs/common';
import { IdentityBankAccountService } from './identity-bank-account.service';

@Module({
  providers: [IdentityBankAccountService]
})
export class IdentityBankAccountModule {}
