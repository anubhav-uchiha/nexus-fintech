import { Injectable } from '@nestjs/common';
import { IdentityService } from '../identity/identity.service';
import { RoleService } from '../role/role.service';
import { JwtService } from '../auth/jwt/jwt.service';
import { CacheService } from 'libs/cache/src';
import { SessionService } from '../session/session.service';

@Injectable()
export class IdentityBankAccountService {
    constructor(
    private readonly identityService: IdentityService,
    private readonly roleService: RoleService,
    private readonly jwtService: JwtService,
    private readonly cache: CacheService,
    private readonly sessionService: SessionService
    ){}
    
    async addBankAccount(data:{
        name:String,
        accNo:String
    }){
        console.log(data.name,data.accNo);
    }   
}
